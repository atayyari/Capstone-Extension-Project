document.getElementById('increaseFontSize').addEventListener('click',
    /*function*/);